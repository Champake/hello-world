function varargout = DoE_GUI(varargin)
%% GUI for a custom three factor multilevel design of experiment.
% Three independent variables (A, B, C) and one dependent variable (Y).
%
% Ivan Brezani (ivan.brezani@tuke.sk)
%
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DoE_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @DoE_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function DoE_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

function varargout = DoE_GUI_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

%% CREATE CODES

% Create table for entering minimum and maximum factor values
function uitable2_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Data', cell(3,3));
set(hObject, 'RowName', {'MIN', 'MAX', 'Name'}, 'ColumnName', {'A', 'B', 'C'});
handles.min_A = -5;
handles.max_A = 5;
handles.min_B = -5;
handles.max_B = 5;
handles.min_C = -5;
handles.max_C = 5;
handles.name_A = 'Variable A';
handles.name_B = 'Variable B';
handles.name_C = 'Variable C';
handles.Rmg = NaN(11,11,11);

dat = [{handles.min_A} {handles.min_B} {handles.min_C};
       {handles.max_A} {handles.max_B} {handles.max_C};
       {handles.name_A} {handles.name_B} {handles.name_C}]; % Default grid for DoE

set(hObject, 'Data', dat)
[handles.Amg, handles.Bmg, handles.Cmg] = meshgrid(linspace(handles.min_A,handles.max_A,11), linspace(handles.min_B,handles.max_B,11), linspace(handles.min_C,handles.max_C,11));
guidata(hObject, handles)

% Fill the table with starting grid point locations (41 data points)
function uitable1_CreateFcn(hObject, eventdata, handles)
N = [0 -2  2 -5  5  0  0  0  0  0  0  0  0  1  1  1  1 -1 -1 -1 -1  4  4  4  4 -4 -4 -4 -4  0  0  0  0  3  3 -3 -3 -3  3 -3  3;
     0  0  0  0  0 -2  2 -5  5  0  0  0  0  1  1 -1 -1  1  1 -1 -1  4  4 -4 -4  4  4 -4 -4  3 -3 -3  3  0  0  0  0 -3 -3  3  3;
     0  0  0  0  0  0  0  0  0 -2  2 -5  5  1 -1  1 -1  1 -1  1 -1  4 -4  4 -4  4 -4  4 -4  3 -3  3 -3  3 -3  3 -3  0  0  0  0];
Y = NaN(1, 41);
set(hObject, 'Data', transpose([N; Y]));
handles.N = N;
handles.M = N;
handles.Y = Y;
guidata(hObject, handles)

% Approximation panel not visible when GUI starts
function uipanel1_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Visible', 'off')
guidata(hObject, handles);

% ANOVA panel not visible when GUI starts
function uipanel2_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Visible', 'off')
guidata(hObject, handles);

% Slice panel not visible when GUI starts
function uipanel3_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Visible', 'off')
guidata(hObject, handles);

% Isosurface panel not visible when GUI starts
function uipanel4_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Visible', 'off')
guidata(hObject, handles);

% Hide panel for scatter of approximated values
function uipanel6_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Visible', 'off')
handles.scatter_invert = 0;
guidata(hObject, handles)

% Set toggle button to on - show numbers in scatter
function togglebutton3_CreateFcn(hObject, eventdata, handles)
set(hObject, 'Value', 1)
handles.scatter_numbered = 1;
guidata(hObject, handles);

% Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
set(hObject, 'Min', 0);
set(hObject, 'Max', 100);
set(hObject, 'Value', 80);

% Button for inverting scatter plot of approximated values 
function pushbutton6_CreateFcn(hObject, eventdata, handles)
handles.scatter_invert = 0;
guidata(hObject, handles)

% Create edit box for Isosurface value setting
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.isovalue = 80;
set(hObject, 'String', [num2str(handles.isovalue) ' %']);
guidata(hObject, handles)

% Create default plot - scatter wit DoE data points
function axes1_CreateFcn(hObject, ~, handles)
%cameratoolbar('Show')
set(gcf, 'toolbar', 'figure' )
plot_scatter(handles);
guidata(hObject, handles);

% Graph pop up menu not visible when GUI starts
function popupmenu1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'Visible', 'off');
guidata(hObject, handles);

%% GUI response

% Scatter "Numbers" function button
function togglebutton3_Callback(hObject, eventdata, handles)
if get(hObject,'Value') == 1
    handles.scatter_numbered = 1;
else
    handles.scatter_numbered = 0;
end
plot_scatter(handles)
guidata(hObject, handles);

% When minimum and maximum values of factors are changed
function uitable2_CellEditCallback(hObject, eventdata, handles)
% Update handles
if isnan(eventdata.NewData) == 0
   if eventdata.Indices == [1 1]
        handles.min_A = eventdata.NewData;
   elseif eventdata.Indices == [1 2]
        handles.min_B = eventdata.NewData;
   elseif eventdata.Indices == [1 3]
        handles.min_C = eventdata.NewData;
   elseif eventdata.Indices == [2 1]
        handles.max_A = eventdata.NewData;
   elseif eventdata.Indices == [2 2]
        handles.max_B = eventdata.NewData;
   elseif eventdata.Indices == [2 3]
        handles.max_C = eventdata.NewData;
   elseif eventdata.Indices == [3 1]
        handles.name_A = eventdata.NewData;
   elseif eventdata.Indices == [3 2]
        handles.name_B = eventdata.NewData;
   elseif eventdata.Indices == [3 3]
        handles.name_C = eventdata.NewData;
   end
end

% Update data point locations in second table
A = [-5 -4 -2 -1 0 1 2 4 5 -3 3];
B = [-5 -4 -2 -1 0 1 2 4 5 -3 3];
C = [-5 -4 -2 -1 0 1 2 4 5 -3 3];
diff_A = (handles.max_A - handles.min_A)/10;
diff_B = (handles.max_B - handles.min_B)/10;
diff_C = (handles.max_C - handles.min_C)/10;
mean_A = (handles.max_A + handles.min_A)/2;
mean_B = (handles.max_B + handles.min_B)/2;
mean_C = (handles.max_C + handles.min_C)/2;
for I = 1:11
    A(I) = mean_A + A(I)*diff_A;
    B(I) = mean_B + B(I)*diff_B;
    C(I) = mean_C + C(I)*diff_C;
end
M = [A(5) A(3) A(7) A(1) A(9) A(5) A(5) A(5) A(5) A(5) A(5) A(5) A(5) A(6) A(6) A(6) A(6) A(4) A(4) A(4) A(4) A(8) A(8) A(8) A(8) A(2) A(2) A(2) A(2) A(5)  A(5)  A(5)  A(5)  A(11) A(11) A(10) A(10) A(10) A(11) A(10) A(11);
     B(5) B(5) B(5) B(5) B(5) B(3) B(7) B(1) B(9) B(5) B(5) B(5) B(5) B(6) B(6) B(4) B(4) B(6) B(6) B(4) B(4) B(8) B(8) B(2) B(2) B(8) B(8) B(2) B(2) B(11) B(10) B(10) B(11) B(5)  B(5)  B(5)  B(5)  B(10) B(10) B(11) B(11);
     C(5) C(5) C(5) C(5) C(5) C(5) C(5) C(5) C(5) C(3) C(7) C(1) C(9) C(6) C(4) C(6) C(4) C(6) C(4) C(6) C(4) C(8) C(2) C(8) C(2) C(8) C(2) C(8) C(2) C(11) C(10) C(11) C(10) C(11) C(10) C(11) C(10) C(5)  C(5)  C(5)  C(5);];
handles.M = M;
set(handles.uitable1, 'Data', transpose([handles.M; handles.Y]));

% Hide uipanels
set(handles.uipanel1, 'Visible', 'off');
set(handles.uipanel2, 'Visible', 'off');
set(handles.uipanel3, 'Visible', 'off');
set(handles.uipanel4, 'Visible', 'off');
set(handles.uipanel5, 'Visible', 'on');
set(handles.uipanel6, 'Visible', 'off');
set(handles.popupmenu1, 'Visible', 'off');
    
% Replot
plot_scatter(handles);
[handles.Amg, handles.Bmg, handles.Cmg] = meshgrid(linspace(handles.min_A,handles.max_A,11), linspace(handles.min_B,handles.max_B,11), linspace(handles.min_C,handles.max_C,11));
guidata(hObject, handles);

% When Y values are changed
function uitable1_CellEditCallback(hObject, eventdata, handles)
if isnan(eventdata.NewData) == 0
     handles.Y(eventdata.Indices(1)) = eventdata.NewData;
end
set(hObject, 'Data', transpose([handles.N; handles.Y]));

% Set visibility of control panels
if sum(isnan(handles.Y)) == 0
    set(handles.uipanel1, 'Visible', 'on');
    set(handles.uipanel2, 'Visible', 'on');
    set(handles.pushbutton3, 'Enable', 'off');
    set(handles.pushbutton4, 'Enable', 'off');
else
    set(handles.uipanel1, 'Visible', 'off');
    set(handles.uipanel2, 'Visible', 'off');
    set(handles.uipanel3, 'Visible', 'off');
    set(handles.uipanel4, 'Visible', 'off');
    set(handles.uipanel6, 'Visible', 'off');
    set(handles.popupmenu1, 'Visible', 'off');
end
guidata(hObject, handles);

% Popupmenu for selection of graph
function popupmenu1_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
str = contents{get(hObject,'Value')};
if str2double(str(1)) == 1
    set(handles.uipanel5, 'Visible', 'on')
    set(handles.uipanel3, 'Visible', 'off')
    set(handles.uipanel4, 'Visible', 'off')
    set(handles.uipanel6, 'Visible', 'off')
    plot_scatter(handles)
elseif str2double(str(1)) == 2
    set(handles.uipanel5, 'Visible', 'off')
    set(handles.uipanel3, 'Visible', 'off')
    set(handles.uipanel4, 'Visible', 'off')
    set(handles.uipanel6, 'Visible', 'on')
    plot_scatter3D(handles)
elseif str2double(str(1)) == 3
    set(handles.uipanel5, 'Visible', 'off')
    set(handles.uipanel3, 'Visible', 'on')
    set(handles.uipanel4, 'Visible', 'off')
    set(handles.uipanel6, 'Visible', 'off')
    plot_contourslice(handles)
else
    set(handles.uipanel5, 'Visible', 'off')
    set(handles.uipanel6, 'Visible', 'off')
    set(handles.uipanel3, 'Visible', 'off')
    set(handles.uipanel4, 'Visible', 'on')
    plot_isosurface(handles)
end
xlabel(handles.name_A)
ylabel(handles.name_B)
zlabel(handles.name_C)
guidata(hObject,handles);

% When animation button is on
function togglebutton1_Callback(hObject, eventdata, handles)
if get(hObject,'Value') == 1
    cla
    vals = linspace( min(handles.Rmg(:)),  max(handles.Rmg(:)), 25);
    axis([handles.min_A handles.max_A handles.min_B handles.max_B handles.min_C handles.max_C]);
    while get(hObject,'Value') == 1
        for id = vals
            cla
            isosurface(handles.Amg, handles.Bmg, handles.Cmg, handles.Rmg, id);
            caxis([min(handles.Rmg(:)), max(handles.Rmg(:))]);
            grid on
            camlight; lighting phong
            pause(0.1);
        end
    end
else
   plot_isosurface(handles) 
end
guidata(hObject, handles);

function plot_isosurface(handles)
cla
isosurface(handles.Amg,handles.Bmg,handles.Cmg,handles.Rmg, min(handles.Rmg(:))+(handles.isovalue/100)*(max(handles.Rmg(:))-min(handles.Rmg(:))))
caxis([min(handles.Rmg(:)), max(handles.Rmg(:))]);
axis([handles.min_A handles.max_A handles.min_B handles.max_B handles.min_C handles.max_C]);
camlight; lighting phong

function plot_scatter3D(handles)
cla
if handles.scatter_invert == 0
    scatter3(handles.Amg(:), handles.Bmg(:), handles.Cmg(:), 5+45*(exp((handles.Rmg(:)-min(handles.Rmg(:)))/(max(handles.Rmg(:))-min(handles.Rmg(:))))-1), handles.Rmg(:), 'filled');
else
    scatter3(handles.Amg(:), handles.Bmg(:), handles.Cmg(:), 127-45*(exp((handles.Rmg(:)-min(handles.Rmg(:)))/(max(handles.Rmg(:))-min(handles.Rmg(:))))-1), handles.Rmg(:), 'filled');
end
axis([handles.min_A handles.max_A handles.min_B handles.max_B handles.min_C handles.max_C]);

function plot_contourslice(handles)
cla
h = slice(handles.Amg, handles.Bmg, handles.Cmg, handles.Rmg,(handles.min_A+handles.max_A)/2,(handles.min_B+handles.max_B)/2,(handles.min_C+handles.max_C)/2);
set(h,'FaceColor','interp',...
	'EdgeColor','none',...
	'DiffuseStrength',.8)
axis([handles.min_A handles.max_A handles.min_B handles.max_B handles.min_C handles.max_C]);
hold off

% Function for plotting DoE basic grid
function plot_scatter(handles)
cla
A = [-5 -4 -2 -1 0 1 2 4 5 -3 3];
B = [-5 -4 -2 -1 0 1 2 4 5 -3 3];
C = [-5 -4 -2 -1 0 1 2 4 5 -3 3];

diff_A = (handles.max_A - handles.min_A)/10;
diff_B = (handles.max_B - handles.min_B)/10;
diff_C = (handles.max_C - handles.min_C)/10;
mean_A = (handles.max_A + handles.min_A)/2;
mean_B = (handles.max_B + handles.min_B)/2;
mean_C = (handles.max_C + handles.min_C)/2;

for I = 1:11
    A(I) = mean_A + A(I)*diff_A;
    B(I) = mean_B + B(I)*diff_B;
    C(I) = mean_C + C(I)*diff_C;
end

M = [A(5) A(3) A(7) A(1) A(9) A(5) A(5) A(5) A(5) A(5) A(5) A(5) A(5) A(6) A(6) A(6) A(6) A(4) A(4) A(4) A(4) A(8) A(8) A(8) A(8) A(2) A(2) A(2) A(2) A(5)  A(5)  A(5)  A(5)  A(11) A(11) A(10) A(10) A(10) A(11) A(10) A(11);
     B(5) B(5) B(5) B(5) B(5) B(3) B(7) B(1) B(9) B(5) B(5) B(5) B(5) B(6) B(6) B(4) B(4) B(6) B(6) B(4) B(4) B(8) B(8) B(2) B(2) B(8) B(8) B(2) B(2) B(11) B(10) B(10) B(11) B(5)  B(5)  B(5)  B(5)  B(10) B(10) B(11) B(11);
     C(5) C(5) C(5) C(5) C(5) C(5) C(5) C(5) C(5) C(3) C(7) C(1) C(9) C(6) C(4) C(6) C(4) C(6) C(4) C(6) C(4) C(8) C(2) C(8) C(2) C(8) C(2) C(8) C(2) C(11) C(10) C(11) C(10) C(11) C(10) C(11) C(10) C(5)  C(5)  C(5)  C(5);];

% Plot scatter using different colors
scatter3(M(1,1),M(2,1),M(3,1),'ko','filled')
hold on
scatter3(M(1,2:13), M(2,2:13), M(3,2:13), 'ro','filled')
scatter3(M(1,14:29),M(2,14:29),M(3,14:29),'bo','filled')
scatter3(M(1,30:41),M(2,30:41),M(3,30:41),'go','filled')

% Add axis lines
line3(M(1:3,4),  M(1:3,5),  'Color', 'r', 'LineStyle', '--')
line3(M(1:3,8),  M(1:3,9),  'Color', 'r', 'LineStyle', '--')
line3(M(1:3,12), M(1:3,13), 'Color', 'r', 'LineStyle', '--')

% Add outer box
line3(M(1:3,22), M(1:3,23), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,22), M(1:3,24), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,22), M(1:3,26), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,23), M(1:3,25), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,23), M(1:3,27), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,24), M(1:3,25), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,24), M(1:3,28), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,25), M(1:3,29), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,26), M(1:3,27), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,26), M(1:3,28), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,27), M(1:3,29), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,28), M(1:3,29), 'Color', 'b', 'LineStyle', '-')

% Add inner box
line3(M(1:3,14), M(1:3,15), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,14), M(1:3,16), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,14), M(1:3,18), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,15), M(1:3,17), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,15), M(1:3,19), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,16), M(1:3,17), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,16), M(1:3,20), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,17), M(1:3,21), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,18), M(1:3,19), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,18), M(1:3,20), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,19), M(1:3,21), 'Color', 'b', 'LineStyle', '-')
line3(M(1:3,20), M(1:3,21), 'Color', 'b', 'LineStyle', '-')

% Add cubooctahedron
line3(M(1:3,30), M(1:3,34),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,30), M(1:3,36),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,30), M(1:3,40),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,30), M(1:3,41),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,31), M(1:3,35),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,31), M(1:3,37),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,31), M(1:3,39),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,31), M(1:3,38),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,32), M(1:3,34),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,32), M(1:3,36),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,32), M(1:3,38),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,32), M(1:3,39),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,33), M(1:3,35),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,33), M(1:3,37),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,33), M(1:3,40),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,33), M(1:3,41),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,34), M(1:3,39),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,34), M(1:3,41),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,35), M(1:3,39),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,35), M(1:3,41),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,36), M(1:3,38),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,36), M(1:3,40),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,37), M(1:3,38),'Color', 'g', 'LineStyle', '-')
line3(M(1:3,37), M(1:3,40),'Color', 'g', 'LineStyle', '-')

% Add number to each point
if handles.scatter_numbered == 1
    for I = 1:41
        text(M(1,I)+0.2*diff_A,M(2,I)+0.2*diff_B,M(3,I)+0.2*diff_C,num2str(I));
    end
end    
xlabel(handles.name_A)
ylabel(handles.name_B)
zlabel(handles.name_C)
hold off

% Calculate approximation of experimental data values
function pushbutton1_Callback(hObject, eventdata, handles)

set(handles.uitable1, 'Data', transpose([handles.M; handles.Y]));
[Xmg, Ymg, Zmg] = meshgrid(1:1:11,1:1:11,1:1:11); 
Rmg = NaN(size(Xmg));
for I=1:41
    Rmg(handles.N(1,I)+6, handles.N(2,I)+6, handles.N(3,I)+6) = handles.Y(I);
end

% Approximation of three basic axes
RX = NaN(11,4);
RY = NaN(11,4);
RZ = NaN(11,4);

% Approximation of three basic planes
[R] = section('XY', 6, Xmg,Ymg,Zmg,Rmg);
RX(1:11,1) = R(1:11,6);
RY(1:11,1) = R(6,1:11);
[R] = section('XZ', 6, Xmg,Ymg,Zmg,Rmg);
RZ(1:11,1) = R(1:11,6);
RY(1:11,2) = R(6,1:11);
[R] = section('YZ', 6, Xmg,Ymg,Zmg,Rmg);
RX(1:11,2) = R(6,1:11);
RZ(1:11,2) = R(1:11,6);

% Approximation of six diagonal planes
[R] = diagonal([1 1 0],Xmg,Ymg,Zmg,Rmg);
RZ(1:11,3) = R(1:11,6);
[R] = diagonal([1 0 1],Xmg,Ymg,Zmg,Rmg);
RX(1:11,3) = R(6,1:11);
[R] = diagonal([0 1 1],Xmg,Ymg,Zmg,Rmg);
RY(1:11,3) = R(6,1:11);
[R] = diagonal([1 -1 0],Xmg,Ymg,Zmg,Rmg);
RZ(1:11,4) = R(1:11,6);
[R] = diagonal([1 0 -1],Xmg,Ymg,Zmg,Rmg);
RX(1:11,4) = R(6,1:11);
[R] = diagonal([0 1 -1],Xmg,Ymg,Zmg,Rmg);
RY(1:11,4) = R(6,1:11);

% Approximation using inner box
RX(1:11,5) = NaN(11,1);
RY(1:11,5) = NaN(11,1);
RZ(1:11,5) = NaN(11,1);
[X,Y] = meshgrid([0, 1, 2], [0, 1, 2]);
x = [0 0 2 2];
y = [0 2 2 0];

z = [handles.Y(19) handles.Y(18) handles.Y(20) handles.Y(21)];
R = griddata(x,y,z,X,Y,'cubic');
RX(5,5) = R(2,2);
z = [handles.Y(17) handles.Y(16) handles.Y(14) handles.Y(15)];
R = griddata(x,y,z,X,Y,'cubic');
RX(7,5) = R(2,2);
z = [handles.Y(21) handles.Y(20) handles.Y(16) handles.Y(17)];
R = griddata(x,y,z,X,Y,'cubic');
RY(5,5) = R(2,2);
z = [handles.Y(19) handles.Y(18) handles.Y(14) handles.Y(15)];
R = griddata(x,y,z,X,Y,'cubic');
RY(7,5) = R(2,2);
z = [handles.Y(19) handles.Y(15) handles.Y(17) handles.Y(21)];
R = griddata(x,y,z,X,Y,'cubic');
RZ(5,5) = R(2,2);
z = [handles.Y(18) handles.Y(14) handles.Y(16) handles.Y(20)];
R = griddata(x,y,z,X,Y,'cubic');
RZ(7,5) = R(2,2);

% Remove extreme values
priem = nanmean(RX');
odch = nanstd(RX');
for I = 1:11
    for J= 1:4
        if priem(I)+2*odch(I) < RX(I,J)
            RX(I,J) = NaN;
        elseif priem(I)-2*odch(I) > RX(I,J)
            RX(I,J) = NaN;
        end
    end
end
RX = nanmean(RX');

priem = nanmean(RY');
odch = nanstd(RY');
for I = 1:11
    for J= 1:4
        if priem(I)+2*odch(I) < RY(I,J)
            RY(I,J) = NaN;
        elseif priem(I)-2*odch(I) > RY(I,J)
            RY(I,J) = NaN;
        end
    end
end      
RY = nanmean(RY');

priem = nanmean(RZ');
odch = nanstd(RZ');
for I = 1:11
    for J= 1:4
        if priem(I)+2*odch(I) < RZ(I,J)
            RZ(I,J) = NaN;
        elseif priem(I)-2*odch(I) > RZ(I,J)
            RZ(I,J) = NaN;
        end
    end
end      
RZ = nanmean(RZ');

% Update main matrix - three basic axes
Rmg(1:11,6,6) = RX;
Rmg(6,1:11,6) = RY;
Rmg(6,6,1:11) = RZ;
clear('RX','RY','RZ','odch','priem')

% Approximate three basic planes
[X2,Y2] = meshgrid([0, 1, 2], [0, 1, 2]);
x2 = [0 1 2 1];
y2 = [1 2 1 0];
R2 = NaN(12,6);

[R] = section('XY', 6, Xmg,Ymg,Zmg,Rmg);
R2(1,1:4) = [5 5 6 R(5,5)];
R2(2,1:4) = [5 7 6 R(5,7)];
R2(3,1:4) = [7 5 6 R(7,5)];
R2(4,1:4) = [7 7 6 R(7,7)];
[R] = section('XZ', 6, Xmg,Ymg,Zmg,Rmg);
R2(9, 1:4) = [6 5 5 R(5,5)];
R2(10,1:4) = [6 5 7 R(7,5)];
R2(11,1:4) = [6 7 5 R(5,7)];
R2(12,1:4) = [6 7 7 R(7,7)];
[R] = section('YZ', 6, Xmg,Ymg,Zmg,Rmg);
R2(5,1:4) = [5 6 5 R(5,5)];
R2(6,1:4) = [5 6 7 R(7,5)];
R2(7,1:4) = [7 6 5 R(5,7)];
R2(8,1:4) = [7 6 7 R(7,7)];

% Approximation using red-blue rhombuses
z2 = [handles.Y(2) handles.Y(20) handles.Y(6) handles.Y(21)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(1,5) = R(2,2);
z2 = [handles.Y(7) handles.Y(18) handles.Y(2) handles.Y(19)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(2,5) = R(2,2);
z2 = [handles.Y(6) handles.Y(16) handles.Y(3) handles.Y(17)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(3,5) = R(2,2);
z2 = [handles.Y(3) handles.Y(14) handles.Y(7) handles.Y(15)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(4,5) = R(2,2);

z2 = [handles.Y(10) handles.Y(21) handles.Y(2) handles.Y(19)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(5,5) = R(2,2);
z2 = [handles.Y(18) handles.Y(11) handles.Y(20) handles.Y(2)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(6,5) = R(2,2);
z2 = [handles.Y(10) handles.Y(15) handles.Y(3) handles.Y(17)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(7,5) = R(2,2);
z2 = [handles.Y(3) handles.Y(16) handles.Y(11) handles.Y(14)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(8,5) = R(2,2);

z2 = [handles.Y(6) handles.Y(17) handles.Y(10) handles.Y(21)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(9,5) = R(2,2);
z2 = [handles.Y(6) handles.Y(20) handles.Y(11) handles.Y(16)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(10,5) = R(2,2);
z2 = [handles.Y(19) handles.Y(7) handles.Y(15) handles.Y(10)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(11,5) = R(2,2);
z2 = [handles.Y(7) handles.Y(14) handles.Y(11) handles.Y(18)];
R = griddata(x2,y2,z2,X2,Y2,'cubic');
R2(12,5) = R(2,2);

% Approximation of six diagonal planes
R = diagonal([1 1 0],Xmg,Ymg,Zmg,Rmg);
R2(1,6) = R(6,5);
R2(4,6) = R(6,7);
R = diagonal([1 -1 0],Xmg,Ymg,Zmg,Rmg);
R2(3,6) = R(6,5);
R2(2,6) = R(6,7);
R = diagonal([1 0 1],Xmg,Ymg,Zmg,Rmg);
R2(9,6) = R(5,6);
R2(12,6) = R(7,6);
R = diagonal([1 0 -1],Xmg,Ymg,Zmg,Rmg);
R2(11,6) = R(5,6);
R2(10,6) = R(7,6);
R = diagonal([0 1 1],Xmg,Ymg,Zmg,Rmg);
R2(5,6) = R(5,6);
R2(8,6) = R(7,6);
R = diagonal([0 1 -1],Xmg,Ymg,Zmg,Rmg);
R2(6,6) = R(5,6);
R2(7,6) = R(7,6);

% Update main matrix
R2(:,7) = mean(rot90(R2(:,4:6)));
for I = 1:12
    Rmg(R2(I,1), R2(I,2), R2(I,3)) = R2(I,7);
end

% Approximation of diagonal axis
R_dia = NaN(12,11);
R = diagonal([1 1 0],Xmg,Ymg,Zmg,Rmg);
for I = 1:11
   R_dia(1,I) = R(I,I);
   R_dia(11,I) = R(12-I,I);
end
R = diagonal([1 0 1],Xmg,Ymg,Zmg,Rmg);
for I = 1:11
   R_dia(3,I) = R(I,I);
   R_dia(4,I) = R(12-I,I);
end
R = diagonal([0 1 1],Xmg,Ymg,Zmg,Rmg);
for I = 1:11
   R_dia(2,I) = R(I,I);
   R_dia(7,I) = R(I,12-I);
end
R = diagonal([1 -1 0],Xmg,Ymg,Zmg,Rmg);
for I = 1:11
   R_dia(6,I) = R(12-I,12-I);
   R_dia(8,I) = R(I,12-I);
end
R = diagonal([1 0 -1],Xmg,Ymg,Zmg,Rmg);
for I = 1:11
   R_dia(9,I) = R(I,I);
   R_dia(10,I) = R(12-I,I);
end
R = diagonal([0 1 -1],Xmg,Ymg,Zmg,Rmg);
for I = 1:11
   R_dia(12,I) = R(I,I);
   R_dia(5,I) = R(I,12-I);
end

% Calculation of mean diagonal axis values
R_dia(13,1:11) = mean(R_dia(1:3,1:11));
R_dia(14,1:11) = mean(R_dia(4:6,1:11));
R_dia(15,1:11) = mean(R_dia(7:9,1:11));
R_dia(16,1:11) = mean(R_dia(10:12,1:11));
for I = 1:11
    for J = 1:11
        for K = 1:11
            if Xmg(I,J,K) == Ymg(I,J,K) && Xmg(I,J,K) == Zmg(I,J,K) && isnan(Rmg(I,J,K)) == 1
                Rmg(I,J,K) = R_dia(13,I);
            elseif Xmg(I,J,K) == Zmg(I,J,K) && Ymg(I,J,K) == 12-Zmg(I,J,K) && isnan(Rmg(I,J,K)) == 1
                Rmg(I,J,K) = R_dia(14,I);
            elseif Ymg(I,J,K) == Zmg(I,J,K) && Xmg(I,J,K) == 12-Zmg(I,J,K) && isnan(Rmg(I,J,K)) == 1
                Rmg(I,J,K) = R_dia(15,I);
            elseif Xmg(I,J,K) == 12-Zmg(I,J,K) && Ymg(I,J,K) == 12-Zmg(I,J,K) && isnan(Rmg(I,J,K)) == 1
                Rmg(I,J,K) = R_dia(16,I);
            end
        end
    end
end

handles.Rmg87 = permute(Rmg,[2 1 3]);

% Calculate values in the middle of polyhedron squares
Rz = NaN(24,7);
[R] = section('XY', 3, Xmg,Ymg,Zmg,Rmg);
Rz(1,1:7) = R(6,3:9);
Rz(3,1:7) = R(3:9,6);
[R] = section('XY', 9, Xmg,Ymg,Zmg,Rmg);
Rz(5,1:7) = R(6,3:9);
Rz(7,1:7) = R(3:9,6);
[R] = section('XZ', 3, Xmg,Ymg,Zmg,Rmg);
Rz(9,1:7) = R(6,3:9);
Rz(11,1:7) = R(3:9,6);
[R] = section('XZ', 9, Xmg,Ymg,Zmg,Rmg);
Rz(13,1:7) = R(6,3:9);
Rz(15,1:7) = R(3:9,6);
[R] = section('YZ', 3, Xmg,Ymg,Zmg,Rmg);
Rz(17,1:7) = R(6,3:9);
Rz(19,1:7) = R(3:9,6);
[R] = section('YZ', 9, Xmg,Ymg,Zmg,Rmg);
Rz(21,1:7) = R(6,3:9);
Rz(23,1:7) = R(3:9,6);
[R] = section('XY', 6, Xmg,Ymg,Zmg,Rmg);
Rz(10,1:7) = R(3,3:9);
Rz(14,1:7) = R(9,3:9);
Rz(18,1:7) = R(3:9,3);
Rz(22,1:7) = R(3:9,9);
[R] = section('XZ', 6, Xmg,Ymg,Zmg,Rmg);
Rz(2,1:7) = R(3,3:9);
Rz(6,1:7) = R(9,3:9);
Rz(20,1:7) = R(3:9,3);
Rz(24,1:7) = R(3:9,9);
[R] = section('YZ', 6, Xmg,Ymg,Zmg,Rmg);
Rz(4,1:7) = R(3,3:9);
Rz(8,1:7) = R(9,3:9);
Rz(12,1:7) = R(3:9,3);
Rz(16,1:7) = R(3:9,9);

% Update main matrix
Rmg(6,3:9,3) = mean(Rz(1:2,:));
Rmg(3:9,6,3) = mean(Rz(3:4,:));
Rmg(6,3:9,9) = mean(Rz(5:6,:));
Rmg(3:9,6,9) = mean(Rz(7:8,:));
Rmg(3,3:9,6) = mean(Rz(9:10,:));
Rmg(3,6,3:9) = mean(Rz(11:12,:));
Rmg(9,3:9,6) = mean(Rz(13:14,:));
Rmg(9,6,3:9) = mean(Rz(15:16,:));
Rmg(3:9,3,6) = mean(Rz(17:18,:));
Rmg(6,3,3:9) = mean(Rz(19:20,:));
Rmg(3:9,9,6) = mean(Rz(21:22,:));
Rmg(6,9,3:9) = mean(Rz(23:24,:));

clear('Rz')

% Approximate values on three basic planes
[R] = section('XY', 6, Xmg,Ymg,Zmg,Rmg);
Rmg(:,:,6) = R;
[R] = section('XZ', 6, Xmg,Ymg,Zmg,Rmg);
Rmg(6,:,:) = transpose(R);
[R] = section('YZ', 6, Xmg,Ymg,Zmg,Rmg);
Rmg(:,6,:) = transpose(R);

% Approximate values on six diagonal planes
R1 = diagonal([1 1 0],Xmg,Ymg,Zmg,Rmg);
R2 = diagonal([1 0 1],Xmg,Ymg,Zmg,Rmg);
R3 = diagonal([0 1 1],Xmg,Ymg,Zmg,Rmg);
R4 = diagonal([1 -1 0],Xmg,Ymg,Zmg,Rmg);
R5 = diagonal([1 0 -1],Xmg,Ymg,Zmg,Rmg);
R6 = diagonal([0 1 -1],Xmg,Ymg,Zmg,Rmg);

% Update main matrix
for I = 1:11
    Rmg(I,I,:) = R1(:,I);
    Rmg(:,I,I) = R2(I,:);    
    Rmg(I,:,I) = R3(I,:);
    Rmg(12-I,I,:) = R4(:,I);
    Rmg(:,12-I,I) = R5(I,:);
    Rmg(I,:,12-I) = R6(I,:);
end

handles.Rmg495 = permute(Rmg,[2 1 3]);

clear('R1','R2','R3','R4','R5','R6')

% Approximate rest of the planes
for I = 1:4
    [R] = section('XY', I+6, Xmg,Ymg,Zmg,Rmg);
    Rmg(:,:,I+6) = R;
    [R] = section('XY', 6-I, Xmg,Ymg,Zmg,Rmg);
    Rmg(:,:,6-I) = R;
    [R] = section('XZ', I+6, Xmg,Ymg,Zmg,Rmg);
    Rmg(I+6,:,:) = transpose(R);
    [R] = section('XZ', 6-I, Xmg,Ymg,Zmg,Rmg);
    Rmg(6-I,:,:) = transpose(R);
    [R] = section('YZ', I+6, Xmg,Ymg,Zmg,Rmg);
    Rmg(:,I+6,:) = transpose(R);
    [R] = section('YZ', 6-I, Xmg,Ymg,Zmg,Rmg);
    Rmg(:,6-I,:) = transpose(R);
end

% Extrapolation of basic planes using inpaint_nans function
[R] = section('XY', 6, Xmg,Ymg,Zmg,Rmg);
R = inpaint_nans(R);
Rmg(:,:,6) = R;
[R] = section('XZ', 6, Xmg,Ymg,Zmg,Rmg);
R = inpaint_nans(R);
Rmg(6,:,:) = transpose(R);
[R] = section('YZ', 6, Xmg,Ymg,Zmg,Rmg);
R = inpaint_nans(R);
Rmg(:,6,:) = transpose(R);

% Extrapolation of 6 diagonal planes using inpaint_nans function
R1 = diagonal([1 1 0],Xmg,Ymg,Zmg,Rmg);
R1 = inpaint_nans(R1);
R2 = diagonal([1 0 1],Xmg,Ymg,Zmg,Rmg);
R2 = inpaint_nans(R2);
R3 = diagonal([0 1 1],Xmg,Ymg,Zmg,Rmg);
R3 = inpaint_nans(R3);
R4 = diagonal([1 -1 0],Xmg,Ymg,Zmg,Rmg);
R4 = inpaint_nans(R4);
R5 = diagonal([1 0 -1],Xmg,Ymg,Zmg,Rmg);
R5 = inpaint_nans(R5);
R6 = diagonal([0 1 -1],Xmg,Ymg,Zmg,Rmg);
R6 = inpaint_nans(R6);

% Update main matrix
for I = 1:11
    Rmg(I,I,:) = R1(:,I);
    Rmg(:,I,I) = R2(I,:);    
    Rmg(I,:,I) = R3(I,:);
    Rmg(12-I,I,:) = R4(:,I);
    Rmg(:,12-I,I) = R5(I,:);
    Rmg(I,:,12-I) = R6(I,:);
end

% Extrapolation of the rest
for I = 1:4
    [R] = section('XY', I+6, Xmg,Ymg,Zmg,Rmg);
    R = inpaint_nans(R);
    Rmg(:,:,I+6) = R;
    [R] = section('XY', 6-I, Xmg,Ymg,Zmg,Rmg);
    R = inpaint_nans(R);
    Rmg(:,:,6-I) = R;
    [R] = section('XZ', I+6, Xmg,Ymg,Zmg,Rmg);
    R = inpaint_nans(R);
    Rmg(I+6,:,:) = transpose(R);
    [R] = section('XZ', 6-I, Xmg,Ymg,Zmg,Rmg);
    R = inpaint_nans(R);
    Rmg(6-I,:,:) = transpose(R);
    [R] = section('YZ', I+6, Xmg,Ymg,Zmg,Rmg);
    R = inpaint_nans(R);
    Rmg(:,I+6,:) = transpose(R);
    [R] = section('YZ', 6-I, Xmg,Ymg,Zmg,Rmg);
    R = inpaint_nans(R);
    Rmg(:,6-I,:) = transpose(R);
end

% Full matrix
Rmg = permute(Rmg,[2 1 3]);
handles.Rmg = Rmg;

% Enable visibility of components
set(handles.pushbutton3, 'Enable', 'on');
set(handles.pushbutton4, 'Enable', 'on');
set(handles.popupmenu1, 'Visible', 'on');

guidata(hObject, handles);

% Calculate ANOVAN based on 41 experimental data points
function pushbutton2_Callback(hObject, eventdata, handles)
Rmg = NaN(size(handles.Amg));
for I=1:41
    Rmg(handles.N(1,I)+6, handles.N(2,I)+6, handles.N(3,I)+6) = handles.Y(I);
end
button = questdlg('Choose ANOVA model for interactions.','ANOVA model','linear','interaction','full','Linear');
[~,~,STATS] = anovan(Rmg(:),{handles.Amg(:) handles.Bmg(:) handles.Cmg(:)}, 'varnames', {handles.name_A handles.name_B handles.name_C}, 'model', button);

% Calculate ANOVAN based on 87 data poins (some approximation)
function pushbutton3_Callback(hObject, eventdata, handles)
button = questdlg('Choose ANOVA model for interactions.','ANOVA model','linear','interaction','full','Linear');
[~,~,STATS] = anovan(handles.Rmg87(:),{handles.Amg(:) handles.Bmg(:) handles.Cmg(:)}, 'varnames', {handles.name_A handles.name_B handles.name_C}, 'model', button);

% Calculate ANOVAN based on 495 data points (approximated)
function pushbutton4_Callback(hObject, eventdata, handles)
button = questdlg('Choose ANOVA model for interactions.','ANOVA model','linear','interaction','full','Linear');
[~,~,STATS] = anovan(handles.Rmg495(:),{handles.Amg(:) handles.Bmg(:) handles.Cmg(:)}, 'varnames', {handles.name_A handles.name_B handles.name_C}, 'model', button);

% Button for setting properties of slice graph
function pushbutton5_Callback(hObject, eventdata, handles)
answer = inputdlg({'Slice variable A (X-axis) at:' 'Slice variable B (Y-axis) at:' 'Slice variable C (Z-axis) at:'}, 'Slice graph settings', 1, {num2str((handles.min_A+handles.max_A)/2) num2str((handles.min_B+handles.max_B)/2) num2str((handles.min_C+handles.max_C)/2)} );
cla
h = slice(handles.Amg, handles.Bmg, handles.Cmg, handles.Rmg, str2double(answer(1)), str2double(answer(2)), str2double(answer(3))  );
set(h,'FaceColor','interp',...
	'EdgeColor','none',...
	'DiffuseStrength',.8)
xlabel(handles.name_A)
ylabel(handles.name_B)
zlabel(handles.name_C)
guidata(hObject, handles)

% Push button for inverting scatter plot of approximated values
function pushbutton6_Callback(hObject, eventdata, handles)
handles.scatter_invert = get(hObject, 'Value');
plot_scatter3D(handles)
guidata(hObject, handles)

% Isosurface value slider
function slider5_Callback(hObject, eventdata, handles)
handles.isovalue = get(hObject,'Value');
plot_isosurface(handles)
set(handles.edit1, 'String', [num2str(handles.isovalue) ' %'])
guidata(hObject, handles);

function edit1_Callback(hObject, eventdata, handles)
str = get(hObject,'String');
str = str(str~=' ');
str = str(str~='%');
handles.isovalue = str2double(str);
set(handles.edit1, 'String', [num2str(handles.isovalue) ' %'])
set(handles.slider5, 'Value', handles.isovalue)
plot_isosurface(handles)
guidata(hObject, handles)

% Paste data from clipboard (41 numerical Y values)
function pushbutton8_Callback(hObject, eventdata, handles)
import = importdata('-pastespecial');
if size(import) == [41 1]
    if isnumeric(import) == true && sum(isnan(import)) == 0
        handles.Y = transpose(import);
        set(handles.uitable1, 'Data', transpose([handles.M; handles.Y]));
        % Set visibility of control panels
        set(handles.uipanel1, 'Visible', 'on');
        set(handles.uipanel2, 'Visible', 'on');
        set(handles.uipanel5, 'Visible', 'on');
        set(handles.uipanel4, 'Visible', 'off');
        set(handles.uipanel3, 'Visible', 'off');
        set(handles.popupmenu1, 'Visible', 'off');
        set(handles.pushbutton3, 'Enable', 'off');
        set(handles.pushbutton4, 'Enable', 'off');
        plot_scatter(handles)
    else
        warndlg('Data must be numerical values.', 'Y-values paste problem')
    end
else
    warndlg('Data must be 41 cells (41 rows, 1 column) containing numerical values.', 'Y-values paste problem')
end
guidata(hObject, handles)

% Open current graph in new figure
function pushbutton9_Callback(hObject, eventdata, handles)
h2 = figure;
h2 = copyobj(handles.axes1, h2);
set(h2, 'Units', 'normalized', 'Position', [.15 .15 .8 .8]);

% Save output variables to workspace
function pushbutton10_Callback(hObject, eventdata, handles)
h = msgbox('Values (matrices) will be saved as "A", "B", "C", "Y", "Y87" and "Y495"', 'Save variables to workspace');
assignin('base', 'A', handles.Amg);
assignin('base', 'B', handles.Bmg);
assignin('base', 'C', handles.Cmg);
assignin('base', 'Y', handles.Rmg);
assignin('base', 'Y87', handles.Rmg87);
assignin('base', 'Y495', handles.Rmg495);

function pushbutton5_CreateFcn(hObject, eventdata, handles)

function pushbutton1_ButtonDownFcn(hObject, eventdata, handles)
