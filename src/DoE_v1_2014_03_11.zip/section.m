function [R] = section(dir,num, Xmg,Ymg,Zmg,Rmg)
L = 1;
    for I = 1:11
        for J = 1:11
            for K = 1:11
                if strcmp(dir, 'XY') == 1 && isnan(Rmg(I,J,K)) == 0 && Zmg(I,J,K) == num
                    x(L) = Xmg(I,J,K);
                    y(L) = Ymg(I,J,K);
                    z(L) = Rmg(I,J,K);
                    L = L + 1;
                elseif strcmp(dir, 'XZ') == 1 && isnan(Rmg(I,J,K)) == 0 && Ymg(I,J,K) == num
                    x(L) = Xmg(I,J,K);
                    y(L) = Zmg(I,J,K);
                    z(L) = Rmg(I,J,K);
                    L = L + 1;
                elseif strcmp(dir, 'YZ') == 1 && isnan(Rmg(I,J,K)) == 0 && Xmg(I,J,K) == num
                    x(L) = Ymg(I,J,K);
                    y(L) = Zmg(I,J,K);
                    z(L) = Rmg(I,J,K);
                    L = L + 1;
                end
            end
        end
    end
    [X,Y] = meshgrid ([1 2 3 4 5 6 7 8 9 10 11], [1 2 3 4 5 6 7 8 9 10 11]);
    R = griddata(x,y,z,X,Y, 'cubic');
end