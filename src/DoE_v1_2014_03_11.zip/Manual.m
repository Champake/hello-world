%% GUI for evaluation of a custom three variables multilevel DoE
%
%                 Ivan Brezani (ivan.brezani@tuke.sk)
%
% This Graphical User Interface (GUI) was designed as a tool for evaluation
% of results based on custom Design of Experiment (DoE). This three factor,
% multilevel design is based on Central Composite Design (CCD), but with
% more levels for each factor. 41 experiments (combinations) are used.
%
 
%% Starting the GUI
%
% GUI can be started from matlab command line from the directory with
% extracted files by simply running the function:
%
% >> DoE_GUI
%
% Window will appear that will look like:
%
% <<GUI_start.png>>
%
% Main window consist of the input tables (located on the left side) and
% graph (located on the right side of the window). There are two
% input/output tables. First one (top) can be used to change minimum and
% maximum values of variables to be used in the design. It also allows user
% to change the name of three factors (A, B and C) that will be used as
% axis labels.
%
% <<GUI_tab1.png>>
%
% Second table is generated based on values in the first table and it shows
% locations of 41 points (combinations of factors) of the design. Each of
% the variables (A, B and C) is represented by numerical value. 
%
% <<GUI_tab2.png>>
%
% DoE consisting of 41 rows and three columns (A, B and C) can be copied to
% clipboard and pasted into spreadsheet editor, such as MS Excel. Column Y
% will be used for input of the response variable.
%
% To the right of the firs table there are three buttons. First one (top)
% can be used to paste values of response variable (Y) into the second
% table. Second button (middle) can be used to open current graph in a new
% figure window for further customization and for saving. Third button can
% be used to save four output variables (A, B, C and Y). Size of each is
% 11x11x11. Matrices A, B and C represent a three dimensional grid 
% consisting of 11*11*11 = 1331 points between minimum and maximum value of
% each of the three variables. Before the approximation is run, Y matrix
% will consist of only NaN values (if no Y values were input) or 41 typed Y
% values and NaNs. After the approximation is run it will represent 
% approximated (and extrapolated) values at individual grid points.
%
% To the right side of the second table there is a area where panels for
% some basic customization of graphs will be displayed. When the GUI is
% started showing scatter of the basic grid the only option available is
% turning the numbering of individual data points on/off.
 
%% Design of Experiment
%
% This design is custom and only applicable on three variables, which can
% be expressed numerically - minimum and maximum value of each variable.
% Basic grid is then calculated based on these values. Following figure
% represents basic grid where all three variables are in the range [-5 5]. 
%
% <<DoE_grid_full.png>>
%
% When experiments are finished then the output should consist of 41 values
% of response variable (Y). These values can be either typed manually into
% each cell (41 rows of the Y column) or copied from a spreadsheet (values
% must be numerical and the size of the copied area must be 41 rows by 1
% column). After entering the 41 response values, new panel appears (red
% rectangle)
% 
% <<GUI_approx.png>>
%
 
%% Calculate statistics - ANOVA
%
% ANOVA panel can be used to calculate N-way ANOVA using Matlab ANOVAN
% function. Before approximation (using the newly appeared Approximate
% button) it can only be calculated based on 41 entered values. Pressing
% the button opens a dialog box for choosing interaction model (Linear,
% Interaction or Full) of ANOVAN function. After % running the
% approximation, options of calculating ANOVA based on 87 or 495 points
% become available (for more informations on how the 87 and 495 points are
% calculated read the "Approximation" section. Please keep in mind that
% statistics calculated based on more than 41 original values will be
% (more or less) influenced by approximation. I recommend to use 41 points
% for calculation of effect of individual variables and 87 points for
% calculation of effects of interactions between variables.
 
%% Approximation / extrapolation
%
% Approximation uses Matlab function |griddata| for interpolation in 2D
% space on 3 basic planes (XY, XZ and YZ) and 6 diagonal planes. There are
% 13 data points (experimental values) on each basic plane as shown on
% picture below.
%
% <<basic_plane.png>>
%
% On each diagonal plane, there are 15 data points (experimental values) as
% shown on picture below.
%
% <<diagonal_plane.png>>
%
% These 3 basic planes and 6 diagonal planes intersect each other at basic
% axes (X, Y, Z). There are 4 approximations for each axis from such
% intersections. Approximation also takes into account two values
% approximated using planes of inner blue cube (i.e. value between points 1
% and 2 is also calculated using approximation of values inside of square
% consisting of points 18 to 21). Number of approximated points rises
% from 41 (13 on basic axes and 28 outside these axes) to 59 (31 on basic
% axes and 28 outside these axes).
%
% Then approximation of basic planes and diagonals is run again and values
% between points on inner blue cube are calculated. Values calculated from
% red/blue rhombuses are also taken into account (i.e. value between
% points 14 and 18 is calculated as a mean of value from approximation of
% one basic plane - 8,9,12,13, one diagonal plane - 22,25,26,29 and a
% rhombus - 14,18,11,7). This adds 12 new points and rises the number of
% values to 71.
%
% In a third step approximation of diagonals is run again based on newest
% data and values on each of 6 diagonal axes is calculated as an
% intersection of two approximated diagonal planes. This raises the number
% of calculated values by 16 to 87.
%
% Approximation is then used to estimate 735 values. |inpaint_nans|
% function is then used for extrapolation of the remaining values. Final
% matrix consist of 1331 values.
%
% Please note that |inpaint_nans| function must be downloaded from File
% Exchange server.
%
 
%% Display results graphically
%
% Popupmenu that appears above the graph after approximation can be used
% to select one of the three methods for displaying the results.
%
% <<GUI_graphs.png>>
%
% Scatter plot uses filled circles with color (hsv colormap) and size
% varying with value of estimated response variable. Color map and size can
% be inverted as an option. (Example figure is displayed on the right
% side of the below image).
%
% Slice plot is an intersection of three planes. Position of the planes can
% be changed using the settings button. (Example figure is displayed on the
% left side of the below image).
%
% <<scatter_slice.png>>
%
% Isosurface can be used to find "shapes" of hyper surfaces with the same
% value of the output variable.