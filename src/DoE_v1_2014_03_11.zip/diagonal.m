function [R] = diagonal(dir,Xmg,Ymg,Zmg,Rmg)
    L = 1;
    for I = 1:11;
        for J = 1:11;
            for K = 1:11;
                if isequal(dir, [1 1 0]) == 1 && isnan(Rmg(I,J,K)) == 0
                    if Xmg(I,J,K) == Ymg(I,J,K)
                        x(L) = Xmg(I,J,K);
                        y(L) = Zmg(I,J,K);
                        z(L) = Rmg(I,J,K);
                        L = L + 1;
                    end
                elseif isequal(dir, [1 0 1]) == 1 && isnan(Rmg(I,J,K)) == 0
                    if Xmg(I,J,K) == Zmg(I,J,K)
                        x(L) = Ymg(I,J,K);
                        y(L) = Zmg(I,J,K);
                        z(L) = Rmg(I,J,K);
                        L = L + 1;
                    end
                elseif isequal(dir, [0 1 1]) == 1 && isnan(Rmg(I,J,K)) == 0
                    if Ymg(I,J,K) == Zmg(I,J,K)
                        x(L) = Xmg(I,J,K);
                        y(L) = Ymg(I,J,K);
                        z(L) = Rmg(I,J,K);
                        L = L + 1;
                    end
                elseif isequal(dir, [1 -1 0]) == 1 && isnan(Rmg(I,J,K)) == 0
                    if Xmg(I,J,K) == 12-Ymg(I,J,K)
                        x(L) = Xmg(I,J,K);
                        y(L) = Zmg(I,J,K);
                        z(L) = Rmg(I,J,K);
                        L = L + 1;
                    end
                elseif isequal(dir, [1 0 -1]) == 1 && isnan(Rmg(I,J,K)) == 0
                    if Xmg(I,J,K) == 12-Zmg(I,J,K)
                        x(L) = Ymg(I,J,K);
                        y(L) = Zmg(I,J,K);
                        z(L) = Rmg(I,J,K);
                        L = L + 1;
                    end
                elseif isequal(dir, [0 1 -1]) == 1 && isnan(Rmg(I,J,K)) == 0
                    if Ymg(I,J,K) == 12-Zmg(I,J,K)
                        x(L) = Xmg(I,J,K);
                        y(L) = Ymg(I,J,K);
                        z(L) = Rmg(I,J,K);
                        L = L + 1;
                    end
                end           
            end
        end
    end
    [X,Y] = meshgrid ([1 2 3 4 5 6 7 8 9 10 11], [1 2 3 4 5 6 7 8 9 10 11]);
    R = griddata(x,y,z,X,Y,'cubic');
end

