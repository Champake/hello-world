function line3(C1, C2, P1, P2, P3, P4)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
line([C1(1), C2(1)], [C1(2), C2(2)], [C1(3), C2(3)], P1, P2, P3, P4)


end

