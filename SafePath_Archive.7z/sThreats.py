# -*- coding: utf-8 -*-
# ###################################
# Program: sPath.py
# Editor: Champ
# Last Modified: 15-March-2019
# ###################################

#%%file graph.txt
node0, node1 0.04, node8 11.11, node14 72.21
node1, node46 1247.25, node6 20.59, node13 64.94;