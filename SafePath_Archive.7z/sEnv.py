# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 14:11:00 2019
Environment Original by Paul Brodersen
@author: champ
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.path as mpath
import matplotlib.patches as mpatches
from scipy.stats import multivariate_normal
# map dimensions
w = 100
h = 100
d = 10
plt.figure(figsize=(w, h), dpi=d)
fig, ax = plt.subplots()
ax.axis([0, 100, 0, 100])

# create 2 kernels
m1 = (-1,-1)
s1 = np.eye(2)
k1 = multivariate_normal(mean=m1, cov=s1)

m2 = (1,1)
s2 = np.eye(2)
k2 = multivariate_normal(mean=m2, cov=s2)

m3 = (4,4)
s3 = np.eye(2)
k3 = multivariate_normal(mean=m3, cov=s3)

m4 = (8,3)
s4 = np.eye(2)
k4 = multivariate_normal(mean=m4, cov=s4)

m5 = (3,7)
s5 = np.eye(2)
k5 = multivariate_normal(mean=m5, cov=s5)

m6 = (6,7)
s6 = np.eye(2)
k6 = multivariate_normal(mean=m6, cov=s6)

m7 = (12,3)
s7 = np.eye(2)
k7 = multivariate_normal(mean=m7, cov=s7)

m8 = (1,12)
s8 = np.eye(2)
k8 = multivariate_normal(mean=m8, cov=s8)

m9 = (10,10)
s9 = np.eye(2)
k9 = multivariate_normal(mean=m9, cov=s9)

m10 = (12,12)
s10 = np.eye(2)
k10 = multivariate_normal(mean=m10, cov=s10)

# create a grid of (x,y) coordinates at which to evaluate the kernels
xlim = (-3, 15)
ylim = (-3, 15)
xres = 100
yres = 100

x = np.linspace(xlim[0], xlim[1], xres)
y = np.linspace(ylim[0], ylim[1], yres)
xx, yy = np.meshgrid(x,y)

# evaluate kernels at grid points
xxyy = np.c_[xx.ravel(), yy.ravel()]
zz = k1.pdf(xxyy) + k2.pdf(xxyy) + \
    k3.pdf(xxyy)+ k4.pdf(xxyy)+ k5.pdf(xxyy) + \
    k6.pdf(xxyy)+ k7.pdf(xxyy)+ k8.pdf(xxyy) + \
    k9.pdf(xxyy)+ k10.pdf(xxyy)

# reshape and plot image
img = zz.reshape((xres,yres))
plt.imshow(img); 

# draw path
string_path_data = [
    (mpath.Path.MOVETO, (0, 0)),
    (mpath.Path.LINETO, (10, 15)),
    (mpath.Path.LINETO, (60, 75)),
    (mpath.Path.LINETO, (100, 100))]

codes, verts = zip(*string_path_data)
string_path = mpath.Path(verts, codes)
patch = mpatches.PathPatch(string_path, facecolor="none", lw=3)

ax.add_patch(patch)
xl, yl = zip(*string_path.vertices)
line, = ax.plot(xl,yl, 'go-')
ax.grid()

plt.show()