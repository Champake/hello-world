# -*- coding: utf-8 -*-
# ###################################
# Program: sMAIN.py
# Editor: Champ
# Last Modified: 15-March-2019
# ###################################
# Setting the ECnvironment

import numpy as np
import matplotlib.pyplot as plt
from math import pi,atan2

from sUTIL import * 
from sPFMVPT import *
# 
# MAIN PROGRAM
print("potential_field_planning start")

sx = 0.0  # start x position [m]
sy = 10.0  # start y positon [m]
gx = 30.0  # goal x position [m]
gy = 30.0  # goal y position [m]
grid_size = 0.5  # potential grid size [m]
robot_radius = 5.0  # robot radius [m]

#graph = read_graph('graph3.txt') 
oList = read_object('SPP_input3.txt')
ox = [];oy = [];tx = [];ty = []

for node in oList.items(): 
    ss = node[0][0]
    if ss =='o':
        ox.append(node[1][0][0])
        oy.append(node[1][0][1])
    else:
        tx.append(node[1][0][0])
        ty.append(node[1][0][1])
                  
# =============================================================================
# #,
# ox = [15.0, 5.0, 20.0, 25.0, 5.0, 12.5, 20.5, 6.5, 18.5, 16.0 ]  # obstacle x position list [m]
# oy = [25.0, 15.0, 26.0, 25.0,15.0, 16.0, 20.0, 25.0, 18.0, 19.0 ]  # obstacle y position list [m]
#    
plt.grid(True)
plt.axis("equal")
plt.xlabel("x-direction")
plt.ylabel("y-direction")
  
  # path generation
rrx, rry, pmap = potential_field_planning(
 sx, sy, gx, gy, ox, oy, tx, ty, grid_size, robot_radius)
  
  #    draw_heatmap(pmap)
 
plt.plot(rrx, rry, "b--", ox, oy, ".r", tx, ty, "xm", markersize=24)
plt.xlabel('x-direction')
plt.ylabel('y-direction')
plt.show();
# =============================================================================
# 
# =============================================================================

