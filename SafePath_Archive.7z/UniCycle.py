
# coding: utf-8

# # Unicycle Dynamics
# 
# 
# <a id='index-0'></a>

# $\textbf{UniCycle Method}$
# 
# This implements the simple Unicycle Model

# $\underline{\textbf{Setting the Environment}}$

# In[13]:


import math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import os


# In[14]:


# Initial and end values
st = 0          # Start time (s)
et = 20         # End time (s)
ts = 5          # Time step (s)
g = 9.81        # Acceleration due to gravity (m/s^2)
L = 1           # Length of pendulum (m)
b = 0.5         # Damping factor (kg/s)
m = 1           # Mass of bob (kg)
V = 30
theta_e = 10


# In[3]:


def calc_input():
    v = 1.0  # [m/s]
    yawrate = 0.1  # [rad/s]
    u = np.array([[v, yawrate]]).T
    return u


# In[4]:


"""
 theta1 is angular displacement at current time instant
 theta2 is angular velocity at current time instant
 dtheta2_dt is angular acceleration at current time instant
 dtheta1_dt is rate of change of angular displacement at current time instant i.e. same as theta2 
"""

def sim_uni_eq(t,theta):
		x_dt = V*np.cos(theta)
		return [x_dt]


# In[23]:


# main
sx = 0.0  # start x position [m]
sy = 0.0  # start y positon [m]
gx = 30.0  # goal x position [m]
gy = 30.0  # goal y position [m]
    
theta1_ini = 0                 # Initial angular displacement (rad)
theta2_end = 50                # Initial angular velocity (rad/s)
theta_span = [theta1_ini, theta2_end]
t_span = [st,et+ts]
t = np.arange(st,et+ts,ts)
theta_span = [theta1_ini,theta2_end+theta_e]
theta = np.arange(theta1_ini,theta2_end+theta_e,theta_e)
# theta12 = solve_ivp(sim_uni_eq, theta_span, theta1_ini, t_eval = t)
print (t)
print (theta)

rx = [0,0,0,0,0,0]
ry = [0,0,0,0,0,0]

for idx in range(1,5):
    rx[idx] = rx[idx-1] + V*np.cos(theta[idx])
    ry[idx] = ry[idx-1] + V*np.sin(theta[idx])

print (rx)
print (ry)
plt.plot(rx, ry, "b--")
plt.xlabel('x-direction')
plt.ylabel('y-direction')
plt.show();
#


# $\textit{By Dr Champ Mendis, AVS, 16-May-2019}$
