# -*- coding: utf-8 -*-
"""
Program: sPathPFVP.py
Purpose: Potential Field based path planner with Vehicle Profile
Author: Champ Mendis, DST
Last Modified: 16-May-2019
"""

# Setting the Environment

import numpy as np
import matplotlib.pyplot as plt
from math import pi,atan2

# Tuning Parameters
# 
APG = 5.0  # attractive potential gain
RPG = 100.0  # repulsive potential gain
P_AREA_WIDTH = 30.0  # potential area width [m]

def xy_attractive_potential(x, y, gx, gy):
    return 0.5 * APG * np.hypot(x - gx, y - gy)

def xy_repulsive_potential(x, y, ox, oy, rr):
    # search nearest obstacle
    minid = -1
    dmin = float("inf")
    for i, _ in enumerate(ox):
        d = np.hypot(x - ox[i], y - oy[i])
        if dmin >= d:
            dmin = d
            minid = i

    # calc repulsive potential
    dq = np.hypot(x - ox[minid], y - oy[minid])

    if dq <= rr:
        if dq <= 0.1:
            dq = 0.1

        return 0.5 * RPG * (1.0 / dq - 1.0 / rr) ** 2
    else:
        return 0.0
    
def calc_potential_field(gx, gy, ox, oy, reso, rr):
     minx = min(ox) - P_AREA_WIDTH / 2.0
     miny = min(oy) - P_AREA_WIDTH / 2.0
     maxx = max(ox) + P_AREA_WIDTH / 2.0
     maxy = max(oy) + P_AREA_WIDTH / 2.0
     xw = int(round((maxx - minx) / reso))
     yw = int(round((maxy - miny) / reso))
     
     # calc each potential
     pmap = [[0.0 for i in range(yw)] for i in range(xw)]
     
     for ix in range(xw):
         x = ix * reso + minx
     
         for iy in range(yw):
             y = iy * reso + miny
             ug = xy_attractive_potential(x, y, gx, gy)
             uo = xy_repulsive_potential(x, y, ox, oy, rr)
             uf = ug + uo
             pmap[ix][iy] = uf
     
     return pmap, minx, miny
# 
def get_motion_model():
     # dx, dy
     motion = [[1, 0],
               [0, 1],
               [-1, 0],
               [0, -1],
               [-1, -1],
               [-1, 1],
               [1, -1],
               [1, 1]]
 
     return motion
# 
     
def get_vehicle_profile():
     # 360 Degree Direction
     profile = [0.99,
                0.3,
                0.3,
                0.4,
                0.4,
                0.9,
                0.9,
                0.99]
 
     return profile
 
def draw_heatmap(data):
     data = np.array(data).T
     plt.pcolor(data, vmax=200.0, cmap=plt.cm.Blues)

#    
def xy_angle(x1, y1, x2, y2):
    return atan2(y2-y1, x2-x1) * 180/pi

#     
def potential_field_planning(sx, sy, gx, gy, ox, oy, reso, rr):
 
     # calc potential field
     pmap, minx, miny = calc_potential_field(gx, gy, ox, oy, reso, rr)
     
     # search path
     d = np.hypot(sx - gx, sy - gy)
     ix = round((sx - minx) / reso)
     iy = round((sy - miny) / reso)
     gix = round((gx - minx) / reso)
     giy = round((gy - miny) / reso)
     
     draw_heatmap(pmap)
     plt.plot(ix, iy, "*k")
     plt.plot(gix, giy, "*m")
     
     theta = []
     rx, ry = [sx], [sy]
     motion = get_motion_model()
     vProfile = get_vehicle_profile()
     while d >= reso:
         minp = float("inf")
         minix, miniy = -1, -1
         for i, _ in enumerate(motion):
             inx = int(ix + motion[i][0])
             iny = int(iy + motion[i][1])
             if inx >= len(pmap) or iny >= len(pmap[0]):
                 p = float("inf")  # outside area
             else:
                 oTheta = xy_angle(ix, iy, inx, iny)
                 p = pmap[inx][iny]
                 p = p-vProfile[int(oTheta/45)]
             if minp > p:
                 minp = p
                 minix = inx
                 miniy = iny
         ix = minix
         iy = miniy
         xp = ix * reso + minx
         yp = iy * reso + miny
         d = np.hypot(gx - xp, gy - yp)
         rx.append(xp)
         ry.append(yp)
         theta.append(xy_angle(ix, iy, xp, yp))
         # CM-26Apr19
         
         #plt.plot(ix, iy, ".r")
         plt.pause(0.01)
     
     print("Goal!!")
     
     return rx, ry, pmap
# 
# MAIN PROGRAM
print("potential_field_planning start")
 
sx = 0.0  # start x position [m]
sy = 10.0  # start y positon [m]
gx = 30.0  # goal x position [m]
gy = 30.0  # goal y position [m]
grid_size = 0.5  # potential grid size [m]
robot_radius = 5.0  # robot radius [m]
 
ox = [15.0, 5.0, 20.0, 25.0, 5.0, 12.5, 20.5, 6.5, 18.5, 16.0 ]  # obstacle x position list [m]
oy = [25.0, 15.0, 26.0, 25.0,15.0, 16.0, 20.0, 25.0, 18.0, 19.0 ]  # obstacle y position list [m]
   
plt.grid(True)
plt.axis("equal")
plt.xlabel("x-direction")
plt.ylabel("y-direction")
 
 # path generation
rrx, rry, pmap = potential_field_planning(
sx, sy, gx, gy, ox, oy, grid_size, robot_radius)
 
 #    draw_heatmap(pmap)

plt.plot(rrx, rry, "b--", ox, oy, ".r", markersize=18)
plt.xlabel('x-direction')
plt.ylabel('y-direction')
plt.show();
# 
# =============================================================================
